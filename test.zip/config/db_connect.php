<?php
   $conn = mysqli_connect('localhost','butterfly','test123','opencode_pizza');

   if(!$conn)
   {
      echo 'connection error' . mysql_connect_error();
   }

?>