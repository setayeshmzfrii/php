<?php 

$names = ['mandana', 'setayesh', 'nastaran', 'elina'];
echo $names[2] . '<br';



?>