<?php

   $errors = array('email'=>'','Fullname'=>'','Address'=>''); 
   
if(isset($_POST['submit']))
{
    if(empty($_POST['email']))
    {
        $errors['email'] = 'Error<br>';
    }
    else 
    {
        $email = $_POST['email'];
        if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $errors['email'] = 'email  is not Ok ';
        }
    }
        
    if(empty($_POST['Fullname']))
    {
        $errors['Fullname'] = 'Error<br>';
    }
    else 
    {

        $Fullname = $_POST ['Fullname'];

        if(Preg_match('/^[a-zA-z\s]+ [a-zA-z]*$/' , $Fullname))
        {
            $errors['Fullname'] = 'title must be letters and spaces only';
        }
    }

    if(empty($_POST['Address']))
    {
        $errors['Address'] = 'Error<br>';
    }
    else
    {
        $Address = $_POST['Address'];
        if(!preg_match('/^[a-zA-Z0-9\s]+(,\s?[a-zA-Z\s]*)*$/' ,$Address))
        {
        $errors['Address'] = 'Adrres shoud separated by comma <br>';

        }
    }

    if(!array_filter($errors))
    {
        header('Location: index.php');
    }
}
?>




<!DOCTYPE html>
<html>

    <?php include('templates/header.php'); ?>
    
    <section class= "container pretty">
    <p style="font-family:Comic sans MS; font-size:30px;" class="center tip">Pizza Form</p>
        <form class="white form" action="add.php" method="POST">
            <lable>Your email</lable>
            <input type="text" name="email">
            <div class= "error"><?php echo $errors['email']; ?></div>
            <lable>Your First name and Last name</lable>
            <input type="text" name="Fullname">
            <div class= "error"><?php echo $errors['Fullname']; ?></div>
            <lable>Your Address</lable>
            <input type="text" name="Address">
            <div class= "error"><?php echo $errors['Address']; ?></div>
            <div class="center">
                <input type="submit" name="submit" value="submit" class="btn submit z-depth-0">
            </div>    
        </form>
    </section>
    <?php include('templates/footer.php'); ?>



</html>
