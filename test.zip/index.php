<?php 
   include 'config/db_connect.php';

   $sql = 'SELECT * FROM pizzas';
   $result = mysqli_query($conn , $sql);
   $pizzas = mysqli_fetch_all($result , MYSQLI_ASSOC);

   mysqli_free_result($result);
   mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="setayesh">
   <?php 
   include 'templates/header.php';
   ?>

   <h4 class='center pretty'>Pizza</h4>


   <div class="container">
      
      <div class="row">
         
         <?php foreach($pizzas as $pizza){ ?>
         
            <div class="col s6 m3">
               <div class="card z-depth-0">
                  <div class="card-content center">
                     <h3><?php echo htmlspecialchars($pizza['Fullname']); ?></h3>
                     <div><?php echo htmlspecialchars($pizza['Address']); ?></div>
                  </div>
                  <div class="card-action right-align">
                     <a class="error" href="http://localhost/test/">more info</a>
                  </div>
               </div>
            </div>
         
         
         
         
         
         
         
         
         
         <?php } ?>
   </div>


   <?php 
   include 'templates/footer.php';
   ?>

</html>