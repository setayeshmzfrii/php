<div>
    <h2>
        <?php echo 'My Content' ?>
    </h2>
</div>