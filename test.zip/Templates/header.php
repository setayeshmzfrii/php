<head>
   <title>OpenCode Pizza</title>
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <style>
      .brand-text {
         color: #DEB887 !important;
      }     

      .brand {
         background: #DEB887 !important;
      }
      .tip {
         color: #20B2AA !important;
      }
      .form {
         max-width:390px;
         margin: 5px auto;
         padding: 20px;
      }
      .pretty {
         color: #2E8B57 !important;
         font-family:Monospace !important;
      }
      .submit {
         color: #FFFFE0 !important;
         background: #006400 !important;
      }
      .error {
         color: #FF0000 !important;
         font-family:Monospace !important;
      }
    </style>
</head>
<body class ="grey lighten-2">
   <nav class="white z-depth-0">
      <div class="container">
         <p style="font-family:Comic sans MS;"><a href="https://pizza.ir/" class="brand-logo brand-text">Opencode Pizza</a></p>
         <ul id="nav-mobile" class="right hide-on-small-ana-down">
            <li><a href="http://localhost/test/add.php" class="btn brand z-depth-0">Add a Pizza</a></li>
         </ul>
      </div>
   </nav>