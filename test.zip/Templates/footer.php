
    <footer class="section">
        <div class="center grey-text"> Copyright 2022 opencod</div>
    </footer>
</body>